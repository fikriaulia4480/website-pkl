<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $data['title'] ?? SITE_NAME; ?></title>
  
  <!-- Styles -->
  <link rel="stylesheet" href="<?php echo SITE_URL; ?>/public/assets/css/style.css">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>
  <!-- Header -->
  <header class="site-header glossy-header">
    <div class="container nav-wrap">

      <!-- Logo -->
      <a href="index.php" class="logo">
        <img src="<?php echo SITE_URL; ?>/public/assets/images/Picture (2).png" alt="PT. IBG" class="logo-img">
      </a>

      <!-- Navigation -->
      <nav class="nav-menu">
        <a href="?page=home" class="nav-link">Home</a>
        <a href="?page=about" class="nav-link">Tentang</a>
        <a href="?page=services" class="nav-link">Layanan</a>
        <a href="?page=projects" class="nav-link">Proyek</a>
        <a href="?page=contact" class="nav-link">Kontak</a>
      </nav>

     <!-- CTA (WhatsApp Minimalist) -->
<div class="nav-cta">
  <a href="https://wa.me/<?php echo COMPANY_WHATSAPP; ?>" class="wa-link">
    <img src="<?php echo SITE_URL; ?>/public/assets/images/whhaaaaattatssasss.jpg" alt="WA">
    <span>Hubungi Kami</span>
  </a>
</div>

    </div>
  </header>
